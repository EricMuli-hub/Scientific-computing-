BIT 2118 Scientific Computing - programs from the group work (Tasks 2 to 20)

Install:  pip install numpy scipy matplotlib
Run:      python Task_02_numpy_arrays.py

Task 16 uses np.trapezoid (NumPy 2.0 or later). On older NumPy use np.trapz.
